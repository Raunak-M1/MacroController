# MacroController — Android starter project

## What this project currently does
- Native Android Java project (no third-party runtime libraries).
- Main settings screen.
- Select 1–10 active floating trigger buttons.
- Per-trigger name, width, height and coordinate/delay step list.
- Save settings locally with SharedPreferences.
- Display-over-other-apps permission flow.
- Movable floating launcher and floating trigger panel.
- Each trigger runs one timed **simulation cycle** and then stops.

## Important limitation
This starter project does **not** inject taps into another app or game. It only simulates the configured coordinate sequence using status notifications. Android does not provide a general unrestricted API for injecting touch events into other apps. Do not use Accessibility or other mechanisms to bypass game anti-cheat or app security. The coordinate values here are markers for simulation, not actual game taps.

## Requirements
- Android Studio on a computer is the most reliable build environment.
- JDK 17.
- Android SDK Platform 35 and Build Tools.
- Gradle 8.7 compatible with Android Gradle Plugin 8.6.1.
- For phone-only builds, use a maintained Android IDE that supports Gradle 8.x and AGP 8.6.1. Mobile IDE support varies; this project is not guaranteed to build in every mobile IDE.

## Build APK
1. Open/import this folder as an existing Gradle project.
2. Allow Gradle sync and install missing SDK components.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.
5. Install the APK on your own test device.

Command line alternative:
`gradle assembleDebug`

## Test on Motorola G84 / Android 15
1. Install and open MacroController.
2. Set Number of trigger buttons to 1–10.
3. Set Edit trigger number to a value within the active count.
4. Edit the trigger name, dimensions and macro steps.
5. Macro step format: `x,y,delaySeconds`, one step per line.
   Example:
   `400,700,0.50`
   `600,900,0.25`
6. Delays must be between 0.01 and 10.00 seconds.
7. Tap Save configuration.
8. Tap Enable floating panel. Grant "Display over other apps" permission only to this app.
9. Return and tap Enable floating panel again.
10. Tap the MC launcher, then a trigger. Observe the simulation notifications.
11. Tap Remove floating panel from the main app to stop the overlay service.

## Project structure
- `app/src/main/java/com/raunak/macrocontroller/MainActivity.java`
- `app/src/main/java/com/raunak/macrocontroller/FloatingService.java`
- `app/src/main/AndroidManifest.xml`
- `app/build.gradle`

## Notes
- Change `compileSdk` / `targetSdk` only after checking compatibility with your installed Android Gradle Plugin.
- Android 13+ notification permission is not requested because this demo uses Toasts rather than notifications.
- Overlay permission is granted by the user through Android Settings.
