package com.raunak.macrocontroller;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.view.*;
import android.widget.*;
import java.util.Locale;

public class FloatingService extends Service {
    WindowManager wm;
    WindowManager.LayoutParams launcherParams, panelParams;
    View launcher, panel;
    Handler handler = new Handler(Looper.getMainLooper());
    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+.5f); }

    @Override public void onCreate() {
        super.onCreate();
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        showLauncher();
    }
    int overlayType(){ return WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY; }
    WindowManager.LayoutParams params(int w,int h,int gravity) {
        return new WindowManager.LayoutParams(w,h,overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
    }
    TextView pill(String text) {
        TextView t=new TextView(this); t.setText(text); t.setTextColor(Color.WHITE);
        t.setTextSize(14); t.setGravity(Gravity.CENTER); t.setPadding(dp(12),dp(8),dp(12),dp(8));
        t.setBackgroundColor(Color.rgb(65,55,105)); return t;
    }
    void showLauncher() {
        if(launcher!=null) return;
        TextView b=pill("MC"); launcher=b;
        launcherParams=params(dp(58),dp(58),Gravity.TOP|Gravity.LEFT);
        launcherParams.x=30; launcherParams.y=250;
        wm.addView(launcher,launcherParams);
        b.setOnTouchListener(new View.OnTouchListener(){
            int sx,sy, ox,oy; long down;
            public boolean onTouch(View v, android.view.MotionEvent e) {
                if(e.getAction()==MotionEvent.ACTION_DOWN){ sx=(int)e.getRawX(); sy=(int)e.getRawY(); ox=launcherParams.x; oy=launcherParams.y; down=System.currentTimeMillis(); return true; }
                if(e.getAction()==MotionEvent.ACTION_MOVE){ launcherParams.x=ox+(int)e.getRawX()-sx; launcherParams.y=oy+(int)e.getRawY()-sy; wm.updateViewLayout(launcher,launcherParams); return true; }
                if(e.getAction()==MotionEvent.ACTION_UP){ if(System.currentTimeMillis()-down<250 && Math.abs(e.getRawX()-sx)<10 && Math.abs(e.getRawY()-sy)<10) togglePanel(); return true; }
                return true;
            }
        });
    }
    void togglePanel() { if(panel==null) showPanel(); else removePanel(); }
    void showPanel() {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(10),dp(8),dp(10),dp(8)); box.setBackgroundColor(Color.rgb(35,32,48));
        TextView title=pill("MacroController  •  tap to run once"); box.addView(title);
        android.content.SharedPreferences p=getSharedPreferences("macro",0);
        int count=p.getInt("count",1);
        for(int n=1;n<=count;n++){
            final int id=n;
            String name=p.getString("name_"+n,"Trigger "+n);
            int w=p.getInt("width_"+n,56), h=p.getInt("height_"+n,56);
            TextView t=pill(name); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(w),dp(h)); lp.setMargins(dp(4),dp(4),dp(4),dp(4)); box.addView(t,lp);
            t.setOnClickListener(v -> runOnce(id));
        }
        TextView close=pill("Close panel"); box.addView(close); close.setOnClickListener(v -> removePanel());
        panel=box; panelParams=params(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,Gravity.TOP|Gravity.LEFT);
        panelParams.x=30; panelParams.y=330;
        wm.addView(panel,panelParams);
    }
    void runOnce(int id) {
        android.content.SharedPreferences p=getSharedPreferences("macro",0);
        String text=p.getString("steps_"+id,"400,700,0.50");
        String[] lines=text.split("\\n");
        Toast.makeText(this,"Trigger "+id+": one simulated cycle started",Toast.LENGTH_SHORT).show();
        long elapsed=0;
        for(int i=0;i<lines.length;i++){
            final int step=i+1; String[] a=lines[i].trim().split(",");
            if(a.length!=3) continue;
            try {
                final String detail="Trigger "+id+" • step "+step+" • marker ("+a[0].trim()+","+a[1].trim()+")";
                double delay=Double.parseDouble(a[2].trim());
                elapsed+=(long)(delay*1000);
                handler.postDelayed(() -> Toast.makeText(this,detail,Toast.LENGTH_SHORT).show(),elapsed);
            } catch(Exception ignored) {}
        }
        final int total=lines.length;
        handler.postDelayed(() -> Toast.makeText(this,"Trigger "+id+": one simulated cycle completed ("+total+" steps)",Toast.LENGTH_LONG).show(),elapsed+150);
    }
    void removePanel(){ if(panel!=null){ try{wm.removeView(panel);}catch(Exception ignored){} panel=null; } }
    @Override public int onStartCommand(Intent i,int f,int id){ if(launcher==null) showLauncher(); return START_NOT_STICKY; }
    @Override public void onDestroy(){ removePanel(); if(launcher!=null){try{wm.removeView(launcher);}catch(Exception ignored){} launcher=null;} handler.removeCallbacksAndMessages(null); super.onDestroy(); }
    @Override public IBinder onBind(Intent i){ return null; }
}
