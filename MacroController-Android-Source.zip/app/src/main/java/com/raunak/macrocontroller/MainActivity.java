package com.raunak.macrocontroller;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.Locale;

public class MainActivity extends Activity {
    EditText countInput, selectedInput, nameInput, widthInput, heightInput, xInput, yInput, stepsInput;
    TextView status;
    int selected = 1;
    LinearLayout root;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(247,245,250));
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        buildUi();
        loadSelected();
    }

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    TextView label(String s) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.rgb(35,35,42));
        t.setTextSize(14); t.setPadding(0,dp(10),0,dp(5)); return t;
    }
    EditText edit(String hint) {
        EditText e = new EditText(this); e.setSingleLine(false); e.setHint(hint);
        e.setTextSize(14); e.setPadding(dp(12),dp(8),dp(12),dp(8));
        e.setBackgroundColor(Color.rgb(245,243,248)); return e;
    }
    Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false); return b;
    }
    void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20),dp(22),dp(20),dp(28)); root.setBackgroundColor(Color.WHITE);
        scroll.addView(root); setContentView(scroll);

        TextView title = label("MacroController");
        title.setTextSize(26); title.setTypeface(null, Typeface.BOLD); root.addView(title);
        TextView sub = label("Floating trigger configuration • Android 15");
        sub.setTextColor(Color.GRAY); root.addView(sub);

        root.addView(label("Number of trigger buttons (1–10)"));
        countInput = edit("Example: 3"); root.addView(countInput);
        root.addView(label("Edit trigger number"));
        selectedInput = edit("Example: 1"); root.addView(selectedInput);
        root.addView(label("Trigger name"));
        nameInput = edit("Trigger 1"); root.addView(nameInput);
        root.addView(label("Button width (dp)"));
        widthInput = edit("56"); root.addView(widthInput);
        root.addView(label("Button height (dp)"));
        heightInput = edit("56"); root.addView(heightInput);

        root.addView(label("Macro steps (one per line: x,y,delaySeconds)"));
        stepsInput = edit("400,700,0.50\n600,900,0.25");
        stepsInput.setMinLines(4); stepsInput.setGravity(Gravity.TOP); root.addView(stepsInput);
        TextView note = label("Example: 400,700,0.50 means coordinate marker X=400, Y=700, then wait 0.50 seconds. This starter version SIMULATES the sequence; it does not send touches into games.");
        note.setTextColor(Color.DKGRAY); root.addView(note);

        Button load = button("Load selected trigger"); root.addView(load);
        load.setOnClickListener(v -> {
            try { selected = Integer.parseInt(selectedInput.getText().toString().trim()); loadSelected(); }
            catch(Exception e) { msg("Enter a trigger number from 1 to 10"); }
        });
        Button save = button("Save configuration"); root.addView(save);
        save.setOnClickListener(v -> saveConfig());

        Button overlay = button("Enable floating panel"); root.addView(overlay);
        overlay.setOnClickListener(v -> enableOverlay());

        Button stop = button("Remove floating panel"); root.addView(stop);
        stop.setOnClickListener(v -> { stopService(new Intent(this,FloatingService.class)); msg("Floating panel stopped"); });

        status = label("Status: Ready"); status.setTextColor(Color.rgb(70,70,80)); root.addView(status);
        TextView privacy = label("Privacy: configuration stays on this device. No account or network access is used.");
        privacy.setTextColor(Color.GRAY); root.addView(privacy);
    }

    void loadSelected() {
        if (selected < 1 || selected > 10) { msg("Trigger number must be 1–10"); return; }
        android.content.SharedPreferences p = getSharedPreferences("macro",0);
        countInput.setText(String.valueOf(p.getInt("count",1)));
        selectedInput.setText(String.valueOf(selected));
        nameInput.setText(p.getString("name_"+selected,"Trigger "+selected));
        widthInput.setText(String.valueOf(p.getInt("width_"+selected,56)));
        heightInput.setText(String.valueOf(p.getInt("height_"+selected,56)));
        stepsInput.setText(p.getString("steps_"+selected,"400,700,0.50\n600,900,0.25"));
        msg("Loaded trigger "+selected);
    }

    void saveConfig() {
        try {
            int count = Integer.parseInt(countInput.getText().toString().trim());
            selected = Integer.parseInt(selectedInput.getText().toString().trim());
            int w = Integer.parseInt(widthInput.getText().toString().trim());
            int h = Integer.parseInt(heightInput.getText().toString().trim());
            if(count<1 || count>10) throw new Exception("Button count must be 1–10");
            if(selected<1 || selected>count) throw new Exception("Selected trigger must be within the active button count");
            if(w<32 || w>160 || h<32 || h>160) throw new Exception("Button dimensions must be 32–160 dp");
            String steps = stepsInput.getText().toString().trim();
            validateSteps(steps);
            getSharedPreferences("macro",0).edit()
                .putInt("count",count).putString("name_"+selected,nameInput.getText().toString().trim())
                .putInt("width_"+selected,w).putInt("height_"+selected,h)
                .putString("steps_"+selected,steps).apply();
            msg("Saved trigger "+selected);
        } catch(Exception e) { msg(e.getMessage()==null?"Invalid configuration":e.getMessage()); }
    }

    static void validateSteps(String text) throws Exception {
        if(text.isEmpty()) throw new Exception("Add at least one macro step");
        String[] lines=text.split("\\n");
        if(lines.length>30) throw new Exception("Maximum 30 steps per trigger");
        for(String line:lines) {
            String[] a=line.trim().split(",");
            if(a.length!=3) throw new Exception("Each line must be x,y,delaySeconds");
            int x=Integer.parseInt(a[0].trim()), y=Integer.parseInt(a[1].trim());
            double d=Double.parseDouble(a[2].trim());
            if(x<0||y<0) throw new Exception("Coordinates cannot be negative");
            if(d<0.01||d>10.00) throw new Exception("Delay must be 0.01–10.00 seconds");
        }
    }

    void enableOverlay() {
        saveConfig();
        if(!Settings.canDrawOverlays(this)) {
            Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
            startActivity(i); msg("Allow Display over other apps, then return and tap Enable floating panel again"); return;
        }
        startService(new Intent(this,FloatingService.class));
        msg("Floating panel enabled");
    }
    void msg(String s) { if(status!=null) status.setText("Status: "+s); Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
}
